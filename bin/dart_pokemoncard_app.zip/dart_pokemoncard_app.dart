import 'db.dart';
import 'menu.dart';

void main() async{
  DB dbConnection = DB();
  await dbConnection.connect();
  await dbConnection.iniciarDB();
  Menu menu = Menu(dbConnection);
  menu.menuInicio();
}
import 'package:mysql1/mysql1.dart';

class DB {
  MySqlConnection? _connection;
  connect() async {
    try {
      var settings = ConnectionSettings(
        host: 'localhost',
        port: 3306,
        user: 'root',
        db: 'mypokemoncard_db',
      );
      _connection = await MySqlConnection.connect(settings);
      print('Conexión a la base de datos establecida.');
      return _connection!;
    } catch (e) {
      print('Error al conectar a la base de datos: $e');
    }
  }

  iniciarDB() async {
    if (_connection == null) {
      throw Exception('No hay conexión a la base de datos.');
    }
    try {
      await crearDB(_connection);
      await conectarDB(_connection);
      await crearTablaUsuario(_connection);
      await crearTablaSobre(_connection);
    } catch (error) {
      print('Error al inicializar la base de datos: $error');
    } finally {
      print('Base de datos completada.');
    }
  }

  static crearDB(connection) async{
      await connection!.query('CREATE DATABASE IF NOT EXISTS mypokemoncard_db');
      print('Base de datos creada o ya existente...');
  }

  static conectarDB(connection) async{
    await connection!.query('USE mypokemoncard_db');
    print('Conectado a la base de datos mypokemoncard_db...');
  }

  static crearTablaUsuario(connection) async{
    try {
      await connection!.query('''
        CREATE TABLE IF NOT EXISTS usuario(
        idusuario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(10) NOT NULL
        )
      ''');
      print('Cargando Tabla Usuario ...');
    } catch (error) {
      print('Error al inicializar la tabla usuarios: $error');
    } finally {
      print ('Tabla usuario completada');
    }
  }

    static crearTablaSobre(connection) async{
    try {
      await connection!.query('''
        CREATE TABLE IF NOT EXISTS sobre(
        id_sobre INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(30) NOT NULL UNIQUE,
        cantidad_cartas INT NOT NULL,
        cooldown DATETIME NOT NULL
        )
      ''');
      print('Cargando Tabla Sobre...');
    } catch (error) {
      print('Error al inicializar la tabla sobre: $error');
    } finally {
      print ('Tabla Sobre completada');
    }
  }

  close() async {
    if (_connection!= null) {
      await _connection!.close();
      print('Conexión a la base de datos cerrada.');
    }
  }
}